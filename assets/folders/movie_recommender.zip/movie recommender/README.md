# who is your favorite rapper
A flutter project that asks you questions and gives you an output of your 'favorite rapper'.

In order to run you must have a flutter sdk installed on vscode or intellij. instructions below are to run the application on vscode.

## Getting Started
-Unzip folder 'flutter_cw' in a folder of your choice.

-Open “coad” in vs code or intellij

-Click 'terminal' then in the dropdown click 'new terminal'. in the terminal type 'flutter pub get’, ‘flutter run’, ‘2’.

-Application should run and you can play the game. To play the game you press the buttons to navigate the questions until it gives you your 'favourite rapper'.
