import 'package:flutter/material.dart';

class IntroPage extends StatelessWidget {
  const IntroPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () {
          Navigator.pushReplacementNamed(context, '/Login');
        },
        child: Center(
          child: Container(
            width: 675,
            height: MediaQuery.of(context).size.height * 0.75,
            padding: const EdgeInsets.all(30),
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center, 
              crossAxisAlignment: CrossAxisAlignment.center, 
              children: const [
                Text(
                  'THIS IS A PROOF OF CONCEPT FOR AN APP I MADE, IT IS NOT FIT FOR EDUCATIONAL PURPOSES',
                  textAlign: TextAlign.center, // Add this
                  style: TextStyle(
                    fontSize: 24,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 20), // Add spacing
                Text(
                  'Welcome to Math Club',
                  textAlign: TextAlign.center, // Add this
                  style: TextStyle(
                    fontSize: 24,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10), // Add spacing
                Text(
                  'Click anywhere to continue',
                  textAlign: TextAlign.center, // Add this
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}