Artifical Intelligence, Group 7 Coursework

Each question is labelled via the file names of the Python files. Some of them require Python PIP packages, these are set up for you in requirements.txt. Simply run `pip install -r requirements.txt`. The two packages are:

1. Numpy
2. Matplotlib

Every question asks to input variables. The default set variables are the ones that we've found to be the most ideal. You can just press enter to all of them if you'd not like to input any variables.

`brief.pdf` is the same coursework brief. `contributions.pdf` is just the contributions table modified for our group. 

The dataset for question 4 is attempted to be read from this folder. So please make sure it is present within the folder. 

Thank you!
- Group 7